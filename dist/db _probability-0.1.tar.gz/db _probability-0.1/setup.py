from setuptools import setup

setup(name='db _probability',
      version='0.1',
      description='Gaussian distributions and Binomial distribution',
      packages=['db_probability'],
      author ='Saurabh Ashoka',
      author_email ='saurabhashok93@gmail.com',
      zip_safe=False)
